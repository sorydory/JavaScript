import Component from "./Component.js";

export default class ContentInput extends Component{
    template(){
        return`
        <input type="text" class="appender">
        `;
    }
}