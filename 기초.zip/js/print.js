        //1.경고창 출력
        alert("여러분");
        //2.body안에 출력
        document.write("안녕하세요");
        //3.콘솔에 출력하기
        console.log("재미있는 자바스크립트");
        //4.html DOM 요소 내용으로 출력하기
        document.getElementById("test"), innerHTML="hello";